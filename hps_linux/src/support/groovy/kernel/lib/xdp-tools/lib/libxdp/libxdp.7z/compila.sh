export PATH=$PATH:/opt/arm/bin
export ARCH=arm
export EXTRAVERSION=-MiSTer
export CROSS_COMPILE=/opt/arm/bin/arm-none-linux-gnueabihf-
make