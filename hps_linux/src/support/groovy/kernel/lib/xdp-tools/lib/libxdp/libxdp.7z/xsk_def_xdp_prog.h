// SPDX-License-Identifier: (GPL-2.0 OR BSD-2-Clause)

#ifndef __LIBXDP_XSK_DEF_XDP_PROG_H
#define __LIBXDP_XSK_DEF_XDP_PROG_H

#define XDP_METADATA_SECTION "xdp_metadata"
#define XSK_PROG_VERSION 1

#endif /* __LIBXDP_XSK_DEF_XDP_PROG_H */
